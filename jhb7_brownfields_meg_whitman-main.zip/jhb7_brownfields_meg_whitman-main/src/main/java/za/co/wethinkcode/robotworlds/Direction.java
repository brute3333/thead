package za.co.wethinkcode.robotworlds;

public enum Direction {
    NORTH,SOUTH,WEST,EAST;
}

