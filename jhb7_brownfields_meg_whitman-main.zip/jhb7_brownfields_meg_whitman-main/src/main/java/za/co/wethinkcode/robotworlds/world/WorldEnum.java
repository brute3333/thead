package za.co.wethinkcode.robotworlds.world;

public enum WorldEnum {
    SUCCESS, FAILED_OBSTRUCTED, FAILED_OUTSIDE_WORLD;
}